-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 18-Maio-2016 às 21:34
-- Versão do servidor: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `heavy`
--
CREATE DATABASE IF NOT EXISTS `heavy` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `heavy`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `carrinho`
--

DROP TABLE IF EXISTS `carrinho`;
CREATE TABLE IF NOT EXISTS `carrinho` (
`id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_prod` int(11) NOT NULL,
  `quantia` int(11) NOT NULL DEFAULT '1',
  `tamanho` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `comprado` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Acionadores `carrinho`
--
DROP TRIGGER IF EXISTS `reduzir_estoque`;
DELIMITER //
CREATE TRIGGER `reduzir_estoque` BEFORE DELETE ON `carrinho`
 FOR EACH ROW BEGIN
if OLD.tamanho = 'p' and OLD.comprado = '1' then
	update estoque SET p = p - OLD.quantia where id = OLD.id_prod;
elseif OLD.tamanho = 'm' and OLD.comprado = '1' then
	update estoque SET m = m - OLD.quantia where id = OLD.id_prod;
elseif OLD.tamanho = 'g' and OLD.comprado = '1' then
	update estoque SET g = g - OLD.quantia where id = OLD.id_prod;
else
	update estoque SET gg = gg - OLD.quantia where id = OLD.id_prod;
end if;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `compra`
--

DROP TABLE IF EXISTS `compra`;
CREATE TABLE IF NOT EXISTS `compra` (
`id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `aprovado` tinyint(1) NOT NULL,
  `valor` decimal(10,0) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `compra`
--

INSERT INTO `compra` (`id`, `id_user`, `aprovado`, `valor`) VALUES
(1, 1, 0, '10');

--
-- Acionadores `compra`
--
DROP TRIGGER IF EXISTS `limpa_carrinho`;
DELIMITER //
CREATE TRIGGER `limpa_carrinho` AFTER INSERT ON `compra`
 FOR EACH ROW BEGIN
delete from carrinho where id_user = NEW.id_user;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `estoque`
--

DROP TABLE IF EXISTS `estoque`;
CREATE TABLE IF NOT EXISTS `estoque` (
`id` int(11) NOT NULL,
  `id_prod` int(11) NOT NULL,
  `p` int(11) NOT NULL,
  `m` int(11) NOT NULL,
  `g` int(11) NOT NULL,
  `gg` int(11) NOT NULL,
  `Sexo` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `estoque`
--

INSERT INTO `estoque` (`id`, `id_prod`, `p`, `m`, `g`, `gg`, `Sexo`) VALUES
(1, 1, 9, 99, 8, 0, 'M'),
(2, 2, 10, 10, 10, 8, '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

DROP TABLE IF EXISTS `produto`;
CREATE TABLE IF NOT EXISTS `produto` (
`id` int(11) NOT NULL,
  `nome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descri` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `foto` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id`, `nome`, `descri`, `preco`, `foto`) VALUES
(2, 'Teste', 'Teste', '59.00', 'be5764ecc0e120f3914331f040d96009.jpg'),
(3, 'Teste', ' Teste \r\n', '59.00', '1f2dcebb4f1bccc5264cb7af75849e86.jpg'),
(4, 'Teste', '  Teste  ', '59.00', 'c170c0df03e41e1feaf657ad334d7778.jpg'),
(5, 'Teste', '  Teste  ', '59.00', '3632fa082334da46d7b2ba6978edd9a1.jpg'),
(6, 'Teste', 'Teste', '59.00', '471369f4df55fb11820f29b129365288.jpg'),
(7, 'Teste', 'Teste', '59.00', '471369f4df55fb11820f29b129365288.jpg'),
(8, 'Teste', 'Teste', '59.00', '471369f4df55fb11820f29b129365288.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cpf` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `end` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cep` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `auto` int(11) DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`id`, `email`, `senha`, `cpf`, `nome`, `end`, `cep`, `auto`) VALUES
(1, 'leo.mi.me@gmail.com', 'e41424639e98205a389518e768aa1746', '111.111.111-11', 'Leonardo Mendes', 'rua A,1', '11111-111', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carrinho`
--
ALTER TABLE `carrinho`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `compra`
--
ALTER TABLE `compra`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `estoque`
--
ALTER TABLE `estoque`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produto`
--
ALTER TABLE `produto`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carrinho`
--
ALTER TABLE `carrinho`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `compra`
--
ALTER TABLE `compra`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `estoque`
--
ALTER TABLE `estoque`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `produto`
--
ALTER TABLE `produto`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
