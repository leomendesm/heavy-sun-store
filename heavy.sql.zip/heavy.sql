-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 20-Maio-2016 às 03:00
-- Versão do servidor: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `heavy`
--
CREATE DATABASE IF NOT EXISTS `heavy` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `heavy`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `carrinho`
--

DROP TABLE IF EXISTS `carrinho`;
CREATE TABLE IF NOT EXISTS `carrinho` (
  `id_car` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_prod` int(11) NOT NULL,
  `quantia` int(11) NOT NULL DEFAULT '1',
  `tamanho` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `comprado` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_car`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Acionadores `carrinho`
--
DROP TRIGGER IF EXISTS `reduzir_estoque`;
DELIMITER //
CREATE TRIGGER `reduzir_estoque` BEFORE DELETE ON `carrinho`
 FOR EACH ROW BEGIN
if OLD.tamanho = 'p' and OLD.comprado = '1' then
	update estoque SET p = p - OLD.quantia where id_prod = OLD.id_prod;
elseif OLD.tamanho = 'm' and OLD.comprado = '1' then
	update estoque SET m = m - OLD.quantia where id_prod = OLD.id_prod;
elseif OLD.tamanho = 'g' and OLD.comprado = '1' then
	update estoque SET g = g - OLD.quantia where id_prod = OLD.id_prod;
elseif OLD.tamanho = 'gg' and OLD.comprado = '1' then
	update estoque SET gg = gg - OLD.quantia where id_prod = OLD.id_prod;
end if;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `compra`
--

DROP TABLE IF EXISTS `compra`;
CREATE TABLE IF NOT EXISTS `compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `aprovado` tinyint(1) NOT NULL,
  `valor` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

--
-- Extraindo dados da tabela `compra`
--

INSERT INTO `compra` (`id`, `id_user`, `aprovado`, `valor`) VALUES(35, 1, 1, '250');
INSERT INTO `compra` (`id`, `id_user`, `aprovado`, `valor`) VALUES(36, 1, 1, '150');
INSERT INTO `compra` (`id`, `id_user`, `aprovado`, `valor`) VALUES(37, 1, 1, '250');
INSERT INTO `compra` (`id`, `id_user`, `aprovado`, `valor`) VALUES(38, 1, 1, '50');
INSERT INTO `compra` (`id`, `id_user`, `aprovado`, `valor`) VALUES(39, 1, 0, '0');
INSERT INTO `compra` (`id`, `id_user`, `aprovado`, `valor`) VALUES(40, 1, 1, '50');

--
-- Acionadores `compra`
--
DROP TRIGGER IF EXISTS `limpa_carrinho`;
DELIMITER //
CREATE TRIGGER `limpa_carrinho` AFTER UPDATE ON `compra`
 FOR EACH ROW BEGIN
update carrinho set comprado = 1 where id_user = NEW.id_user;
delete from carrinho where id_user = NEW.id_user;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `estoque`
--

DROP TABLE IF EXISTS `estoque`;
CREATE TABLE IF NOT EXISTS `estoque` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prod` int(11) NOT NULL,
  `p` int(11) NOT NULL,
  `m` int(11) NOT NULL,
  `g` int(11) NOT NULL,
  `gg` int(11) NOT NULL,
  `Sexo` char(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `estoque`
--

INSERT INTO `estoque` (`id`, `id_prod`, `p`, `m`, `g`, `gg`, `Sexo`) VALUES(1, 1, 9, 99, 8, 0, 'M');
INSERT INTO `estoque` (`id`, `id_prod`, `p`, `m`, `g`, `gg`, `Sexo`) VALUES(2, 2, 10, 10, 10, 8, '');
INSERT INTO `estoque` (`id`, `id_prod`, `p`, `m`, `g`, `gg`, `Sexo`) VALUES(3, 9, 10, 10, 10, 3, '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

DROP TABLE IF EXISTS `produto`;
CREATE TABLE IF NOT EXISTS `produto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descri` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `foto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id`, `nome`, `descri`, `preco`, `foto`) VALUES(9, 'camiseta zoo york', 'No meu xinÃ©lo da humildade eu gostaria muito de ver o Neymar e o Ganso. Por que eu acho que.... 11 entre 10 brasileiros gostariam. VocÃª veja, eu jÃ¡ vi, parei de ver. Voltei a ver, e acho que o Neymar e o Ganso tÃªm essa capacidade de fazer a gente olhar.\r\n\r\nTodos as descriÃ§Ãµes das pessoas sÃ£o sobre a humanidade do atendimento, a pessoa pega no pulso, examina, olha com carinho. EntÃ£o eu acho que vai ter outra coisa, que os mÃ©dicos cubanos trouxeram pro brasil, um alto grau de humanidade.\r\n', '49.99', 'd7680bb5990812a502bc35963204bb80.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cpf` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `end` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cep` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `auto` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`id`, `email`, `senha`, `cpf`, `nome`, `end`, `cep`, `auto`) VALUES(1, 'leo.mi.me@gmail.com', 'e41424639e98205a389518e768aa1746', '111.111.111-11', 'Leonardo Mendes', 'rua A,1', '11111-111', 1);
INSERT INTO `user` (`id`, `email`, `senha`, `cpf`, `nome`, `end`, `cep`, `auto`) VALUES(2, 'leo.mi.me.leo@gmail.com', 'e41424639e98205a389518e768aa1746', '111.111.111-12', 'leo', 'rua a', '11111-111', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
